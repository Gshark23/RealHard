#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

# Adreno Idler nền
write /sys/module/adreno_idler/parameters/adreno_idler_active 0

# LPM Tắt để đi vào giấc ngủ
for parameters in /sys/module/lpm_levels/parameters; do
    write $parameters/sleep_disabled N
    write $parameters/lpm_prediction N
    write $parameters/lpm_ipi_prediction N
done

#Snap tweak
for gpu in /sys/class/kgsl/kgsl-3d0
do
  echo "0" > $gpu/adrenoboost
  echo "0" > $gpu/devfreq/adrenoboost
  echo "N" > $gpu/adreno_idler_active
  echo "0" > $gpu/throttling
done

#Tweak For Cool Cpu Core
echo "1" > /dev/cpuset/sched_relax_domain_level
echo "1" > /dev/cpuset/system-background/sched_relax_domain_level
echo "1" > /dev/cpuset/background/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-background/sched_relax_domain_level
echo "1" > /dev/cpuset/foreground/sched_relax_domain_level
echo "1" > /dev/cpuset/top-app/sched_relax_domain_level
echo "1" > /dev/cpuset/restricted/sched_relax_domain_level
echo "1" > /dev/cpuset/asopt/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-daemon/sched_relax_domain_level

# CPU TEMP 95C°
echo "0" > /sys/module/overheat_mitigation/parameters/enable
echo "95000" > /sys/class/thermal/thermal_zone*/trip_point_0_temp
echo "95000" > /sys/class/thermal/thermal_zone*/trip_point_1_temp
echo "0" > /proc/gpufreq/gpufreq_limited_thermal_ignore
echo "0" > /proc/cpufreq/cpufreq_imax_thermal_protect;
echo "UnityMain, libunity.so" > /proc/sys/kernel/sched_lib_name
echo "240" > /proc/sys/kernel/sched_lib_mask_force

# Disable msm_thermal and core_control
echo "N" > /sys/module/msm_thermal/parameters/enabled
echo "0" > /sys/module/msm_thermal/core_control/enabled
echo "0" > /sys/kernel/msm_thermal/enabled

# Disables GPU debugging
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr

# ข้อความ
su -lp 2000 -c "cmd notification post -S bigtext -t '🔥TWEAK🔥' 'Tag' 'Performance ปรับแต่ง CPU-GPU Successfull FixBy@RealHard'"

exit 0
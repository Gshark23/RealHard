#!/system/bin/sh
MODDIR=${0%/*}
write /proc/sys/vm/page-cluster 0
write /sys/block/zram0/max_comp_streams 8

{
    while true; do
        resetprop  -n init.svc.android.thermal-hal stopped
        resetprop  -n init.svc.mi_thermald stopped
        sleep 1;
    done
} &

# Disable unnecessary services for improved stability and power efficiency
stop mpdecision
stop thermal-engine

# Stop mi_thermald service
stop mi_thermald

# Identify services starting with "thermal"
services=$(service list | grep 'thermal')

# Loop through identified services and stop them
while read -r service; do
    service_name=$(echo "$service" | awk '{print $1}')  # Extract service name from the output
    stop "$service_name"
done <<< "$services"

# Search for the thermal.hal.2.0 service
thermal_service=$(service list | grep "thermal.hal.2.0")

if [ -z "$thermal_service" ]; then
  echo "Thermal service (thermal.hal.2.0) not found."
  exit 1
fi

# Extract the thermal service name
thermal_service_name=$(echo "$thermal_service" | awk '{print $1}')

# Stop the thermal service
stop "$thermal_service_name"

# Verify if the thermal service has been stopped
thermal_service_status=$(service check "$thermal_service_name")

if [ "$thermal_service_status" = "running" ]; then
  echo "Failed to stop the thermal service (thermal.hal.2.0)."
  exit 1
else
  echo "Thermal service (thermal.hal.2.0) has been stopped."
  exit 0
fi

# Find the thermal throttling kernel parameters
thermal_params=$(find /sys/devices/ -type d -name "thermal")
if [ -z "$thermal_params" ]; then
  echo "Unable to find thermal parameters!"
  exit 1
fi

# Disable thermal throttling
for param in $thermal_params; do
  echo "Disabling thermal throttling for: $param"
  echo 0 > "$param/throttle_enabled"
done

# Toggle 3D and Rendering Optimization
TOGGLE_3D=1
TOGGLE_RENDERING=1

# Restart SurfaceFlinger for changes to take effect
su -c "service call SurfaceFlinger 1008"

# Magisk Module Script
# Enable Fast Charge for slightly faster battery charging when being connected to a USB 3.1 port
echo 1 > /sys/kernel/fast_charge/force_fast_charge

# Removes all CPU and GPU throttling

# Disable CPU thermal throttling
echo 0 > /sys/module/cpu_boost/parameters/thermal_limit_temp
echo 0 > /sys/module/cpu_boost/parameters/thermal_limit_enabled

# Disable GPU thermal throttling
echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/thermal_throttle/thermal_limit_temp
echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/thermal_throttle/thermal_limit_enabled

# Disable CPU frequency throttling
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/interactive/; do
    echo 0 > "${cpu}enable_freq_resp"
    echo 0 > "${cpu}boost"
done

# Disable GPU frequency throttling
echo 0 > /sys/class/kgsl/kgsl-3d0/devfreq/enable_adaptive_thermal

# Disable CPU thermal and power throttling
echo 0 > /sys/module/msm_thermal/parameters/enabled
echo 0 > /sys/module/msm_thermal/core_control/enabled

# Apply changes
echo 1 > /sys/module/msm_thermal_v3/suspend_mode
echo 0 > /proc/sys/kernel/randomize_va_space
echo 0 > /proc/sys/vm/compact_unevictable_allowed

exit 0

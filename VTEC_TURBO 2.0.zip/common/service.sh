#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 60

# CPU GPU MAXFREQ
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/; do
  cpu_min_freq=$(cat "${cpu}cpuinfo_min_freq")
  cpu_max_freq=$(cat "${cpu}cpuinfo_max_freq")
  echo "CPU Min Freq: $cpu_min_freq"
  echo "CPU Max Freq: $cpu_max_freq"
done

gpu_min_freq=$(cat "${gpu}gpuinfo_min_freq")
gpu_max_freq=$(cat "${gpu}gpuinfo_max_freq")
echo "GPU Min Freq: $gpu_min_freq"
echo "GPU Max Freq: $gpu_max_freq"

Load highspeed
for gov in /sys/devices/system/cpu/*/cpufreq
do
   echo "99" > $gov/schedutil/hispeed_load
   echo "99" > $gov/walt/hispeed_load
done

# Disable Core_ctl  
for cctl in /sys/devices/system/cpu/*/core_ctl
do
  echo "0" > $cctl/enable
done
  
# Adreno Idler
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active

# Disable LPM Parameters
for parameters in /sys/module/lpm_levels/parameters/*
do
    echo "0" > "$parameters/sleep_disabled"
    echo "0" > "$parameters/lpm_prediction"
    echo "0" > "$parameters/lpm_ipi_prediction"
done

# configure LPM
echo "N" > /sys/module/lpm_levels/system/pwr/cpu0/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/cpu1/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/cpu2/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/cpu3/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu4/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu5/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu6/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu7/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/pwr-l2-dynret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/perf-l2-dynret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/pwr-l2-ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/perf-l2-ret/idle_enabled

# Snap tweak
for gpu in /sys/class/kgsl/kgsl-3d0 
do
  echo "N" > $gpu/adreno_idler_active
  echo "0" > $gpu/throttling
done 

#Tweak For Balance Cpu Core
echo "1" > /dev/cpuset/sched_relax_domain_level
echo "1" > /dev/cpuset/system-background/sched_relax_domain_level
echo "1" > /dev/cpuset/background/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-background/sched_relax_domain_level
echo "1" > /dev/cpuset/foreground/sched_relax_domain_level
echo "1" > /dev/cpuset/top-app/sched_relax_domain_level
echo "1" > /dev/cpuset/restricted/sched_relax_domain_level
echo "1" > /dev/cpuset/asopt/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-daemon/sched_relax_domain_level

# perf enable
# echo "1" > /sys/devices/system/cpu/perf/enable
# IO optimización
for queue in /sys/block/*/queue; do
    write $queue/scheduler deadline
    write $queue/iostats 1
    write $queue/rotational 0
    write $queue/read_ahead_kb 1024
    write $queue/add_random 0
    write $queue/nomerges 0
    write $queue/nr_requests 64
    write $queue/rq_affinity 1
    write $queue/iosched/slice_idle 0
    write $queue/iosched/slice_idle_us 0
    write $queue/iosched/group_idle 0
    write $queue/iosched/group_idle_us 0
    write $queue/iosched/back_seek_penalty 1
done

# Increase the read-ahead buffer
echo "1024" > /sys/block/mmcblk0/queue/read_ahead_kb
echo "1024" > /sys/block/mtdblock0/queue/read_ahead_kb
echo "1024" > /sys/block/sda/queue/read_ahead_kb
echo "1024" > /sys/block/sdb/queue/read_ahead_kb
echo "1024" > /sys/block/sdc/queue/read_ahead_kb
echo "1024" > /sys/block/sdd/queue/read_ahead_kb
echo "1024" > /sys/block/sde/queue/read_ahead_kb
echo "1024" > /sys/block/sdf/queue/read_ahead_kb
echo "1024" > /sys/block/zram0/queue/read_ahead_kb

# Change I/O
echo "deadline" > /sys/block/mtdblock0/queue/scheduler
echo "deadline" > /sys/block/mmcblk0/queue/scheduler
echo "deadline" > /sys/block/mmcblk1/queue/scheduler
echo "deadline" > /sys/block/sda/queue/scheduler
echo "deadline" > /sys/block/sdb/queue/scheduler
echo "deadline" > /sys/block/sdc/queue/scheduler
echo "deadline" > /sys/block/sdd/queue/scheduler
echo "deadline" > /sys/block/sde/queue/scheduler
echo "deadline" > /sys/block/sdf/queue/scheduler

# Disable additional thermal controls
for i in /sys/class/thermal/therm* 
do
    echo "0" > $i/passive
    echo "disabled" > $i/mode
    
done 

for i in /sys/class/thermal/*therm 
do
    echo "0" > $i/passive
    echo "disabled" > $i/mode
done 

for i in /sys/class/thermal/cooling_device* 
do
    echo "0" > $i/cur_state
done 

# CPU TEMP 
echo "0" > /sys/class/thermal/thermal_zone*/mode
echo "0" > /sys/module/overheat_mitigation/parameters/enable
echo "0" > /proc/gpufreq/gpufreq_limited_thermal_ignore
echo "0" > /proc/cpufreq/cpufreq_imax_thermal_protect
echo "UnityMain, libunity.so" > /proc/sys/kernel/sched_lib_name
echo "240" > /proc/sys/kernel/sched_lib_mask_force
# echo "105000" > /sys/class/thermal/thermal_zone*/trip_point_*_temp
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "0" > /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
echo "0" > /proc/gpufreq/gpufreq_limited_low_batt_volt_ignore
# echo "1" > /sys/module/perfmgr/parameters/perfmgr_enable
# echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
# echo "performance" > /sys/class/devfreq/soc:qcom,gpubw/governor
# echo "performance" > /sys/class/kgsl/kgsl-3d0/pwrscale/trustzone/governor
# echo "performance" > /sys/class/kgsl/kgsl-3d0/pwrscale/kernelspace/governor
# echo "performance" > /sys/class/kgsl/kgsl-3d0/sampling_factor
# echo "performance" > /sys/class/kgsl/kgsl-3d0/cmdstream_sync_mode
echo "performance" > /sys/class/devfreq/1d84000.ufshc/governor
# echo "0" > /sys/class/thermal/thermal_message/sconfig
# echo "0" > /sys/class/thermal/thermal_message/cpu_limits
# echo "0" > /sys/class/thermal/thermal_message/cpu_nolimit_temp
# echo "0" > /sys/class/thermal/thermal_message/balance_mode
# echo "0" > /sys/class/thermal/thermal_message/temp_state

# Disable msm_thermal and core_control
echo "N" > /sys/module/msm_thermal/parameters/enabled
echo "0" > /sys/module/msm_thermal/core_control/enabled
echo "0" > /sys/kernel/msm_thermal/enabled

# Disables GPU debugging
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
echo "0" > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr

# Hotplug
for hotplug in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl 
do
    write $hotplug/enable "0"
done 

# su -c cmd power set-fixed-performance-mode-enabled true
# su -c settings put global window_animation_scale 0.00248
# su -c settings put global transition_animation_scale 0.00248
# su -c settings put global animator_duration_scale 0.00248
# su -c settings put system power_mode high
# su -c settings put system speed_mode 1
# su -c settings put secure speed_mode_enable 1
su -c settings put system thermal_limit_refresh_rate 0
su -c settings put global transition_animation_duration_ratio 0.2
# su -c settings put secure allow_heat_cooldown_always 0

# ข้อความ
su -lp 2000 -c "cmd notification post -S bigtext -t '🔥TWEAK🔥' 'Tag' 'Performance ⚡ปรับแต่ง⚡ CPU GPU UNLOCKLIMIT Successfull FixBy@RealHard️'"

# Bettery Friendly
echo "N" > /sys/module/workqueue/parameters/power_efficient 
echo "N" > /sys/module/battery_saver/parameters/enabled
echo "200" > /sys/class/power_supply/bms/temp_cool
echo "460" > /sys/class/power_supply/bms/temp_hot
echo "300" > /sys/class/power_supply/bms/temp_warm

# Kernel Debugging (thx to KTSR)
for i in 'debug_mask' 'log_level*' 'debug_level*' '*debug_mode' 'edac_mc_log*' 'enable_event_log' '*log_level*' '*log_ue*' '*log_ce*' 'log_ecn_error' 'snapshot_crashdumper' 'seclog*' 'compat-log' '*log_enabled' 'tracing_on' 'mballoc_debug'; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo "0" > "$o"
done

for parameters in /sys/module/mmc_core/parameters/*; do
    echo "0" > "$parameters/use_spi_crc"
    echo "0" > "$parameters/removable"
    echo "0" > "$parameters/crc"
done

BT=$(getprop ro.boot.bootdevice)
if [ -e /sys/devices/platform/soc/$BT/ufstw_lu0/tw_enable ]; then    
    echo "1" > /sys/devices/platform/soc/$BT/ufstw_lu0/tw_enable
fi
if [ -e /sys/devices/platform/soc/$BT/emmc_turbo_write ]; then
    echo "1" > /sys/devices/platform/soc/$BT/emmc_turbo_write
fi

# disable kernelpanic
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/panic_on_rcu_stall
echo "0" > /proc/sys/kernel/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic
echo "0" > /sys/module/kernel/parameters/panic_on_warn
echo "0" > /sys/module/kernel/parameters/panic_on_oops
echo "0" > /sys/vm/panic_on_oom

enable_kernel_boost() {
    # Qualcomm
    echo "0" > "/sys/devices/system/cpu/cpu_boost/parameters/*"
    echo "0" > "/sys/module/cpu_boost/parameters/*"
}

# Deshabilitar la depuración y el registro del kernel
echo "0" > /sys/module/binder/parameters/debug_mask
echo "0" > /sys/module/binder_alloc/parameters/debug_mask

# Watermark Boost Tweak
echo "0" > /proc/sys/vm/watermark_boost_factor

# Grouping tasks tweak
echo "1" > /proc/sys/kernel/sched_autogroup_enabled

# Touchboost
echo "0" > /sys/module/msm_performance/parameters/touchboost
echo "0" > /sys/power/pnpmgr/touch_boost

for i in /sys/devices/virtual/block/*/queue/iosched; do
  echo "0" > $i/low_latency;
done;

# Disable scheduler statistics to reduce overhead
write /proc/sys/kernel/sched_schedstats "0"

# We are not concerned with prioritizing latency
write /dev/stune/top-app/schedtune.prefer_idle "0"

# Mark top-app as boosted, find high-performing CPUs
write /dev/stune/top-app/schedtune.boost "1"

# Virtual Memory
for virtual_memory in /proc/sys/vm/*; do
    echo '20' > "$virtual_memory/stat_interval"
    echo '0' > "$virtual_memory/page-cluster"
    echo '0' > "$virtual_memory/panic_on_oom"
    echo '3' > "$virtual_memory/drop_caches"
done

for fs in /proc/sys/fs; do
    echo '0' > "$fs/dir-notify-enable"
    echo '1' > "$fs/by-name/userdata/iostat_enable"
done

# Disable tracing
stop traced
write /sys/kernel/tracing/tracing_on 0

# Disable Printk Fully
write /proc/sys/kernel/printk 0 0 0 0 
write /proc/sys/kernel/printk_devkmsg off
write /sys/module/printk/parameters/console_suspend Y
write /sys/module/printk/parameters/cpu N
write /sys/kernel/printk_mode/printk_mode 0
write /sys/module/printk/parameters/ignore_loglevel Y
write /sys/module/printk/parameters/pid N
write /sys/module/printk/parameters/time N

# Disable some debug
write /sys/module/rpm_smd/parameters/debug_mask 0
write /sys/module/msm_show_resume_irq/parameters/debug_mask 0
write /sys/module/rmnet_data/parameters/rmnet_data_log_level 0
write /sys/module/ip6_tunnel/parameters/log_ecn_error N

# Disable Stats
write /proc/sys/kernel/sched_schedstats 0

# Disable CRC
write /sys/module/mmc_core/parameters/use_spi_crc 0

# Disable power efficient workqueue
echo "N" > /sys/module/workqueue/parameters/power_efficient
echo "0" > /sys/devices/system/cpu/sched_mc_power_savings

# Disable Exception-trace and reduce some overhead that is caused by a certain amount and percent of kernel logging, in case your kernel of choice have it enabled;
echo "0" > /proc/sys/debug/exception-trace

# Set the rendering thread priority to a high value
echo -17 > /proc/$$/taskset/cpuset/camera-daemon/cgroup.sched_boost

# Enable GPU boost if supported by the device
echo "1" > /sys/class/kgsl/kgsl-3d0/devfreq/enable_gpu_boost

# Enable VSync to synchronize the display refresh rate and GPU rendering rate
echo "1" > /sys/module/msm_kms/parameters/dynamic_fps

# Disable CPU boost if supported by the device
if [ -e /sys/module/msm_performance/parameters/cpu_boost ]; then
    echo "N" > /sys/module/msm_performance/parameters/cpu_boost
fi

# Disable kernel debugging
echo "0" > /proc/sys/kernel/printk_devkmsg
echo "0" > /proc/sys/kernel/ftrace_enabled

# Clear caches
# Disable RAM debugging
if [ -e /sys/kernel/debug/suspend_stats ]; then
  echo "0" > /sys/kernel/debug/suspend_stats
fi

# Disable CPU debugging
if [ -e /sys/kernel/debug/tracing/events/power/cpu_frequency ]; then
  echo "0" > /sys/kernel/debug/tracing/events/power/cpu_frequency/enable
fi

# Disable extra debugging
if [ -e /sys/module/lowmemorykiller/parameters/ad_ratio ]; then
  echo "0" > /sys/module/lowmemorykiller/parameters/ad_ratio
fi

if [ -e /sys/module/lowmemorykiller/parameters/adj ]; then
  echo "0" > /sys/module/lowmemorykiller/parameters/adj
fi

if [ -e /sys/module/lowmemorykiller/parameters/minfree ]; then
  echo "0" > /sys/module/lowmemorykiller/parameters/minfree
fi

if [ -e /sys/module/lowmemorykiller/parameters/oom_adj ]; then
  echo "-17" > /sys/module/lowmemorykiller/parameters/oom_adj
fi

# Disable I/O randomization for better read efficiency
echo "0" > /proc/sys/vm/dirty_background_ratio
echo "0" > /proc/sys/vm/dirty_ratio
echo "1" > /proc/sys/vm/compact_memory

# Optimize SQLite settings for faster database access
echo "pragma synchronous = off;" > /data/local/tmp/sqlite_optimize.sql
sqlite3 /data/data/com.android.providers.settings/databases/settings.db < /data/local/tmp/sqlite_optimize.sql

# Set proper permissions for module files
# chmod 0644 $MODDIR/*.*
# chmod 0755 #MODDIR/*.*

# Set your desired battery optimization level (1-3)
# 1 - Default optimization
# 2 - Medium optimization
# 3 - Maximum optimization
BATTERY_OPTIMIZATION_LEVEL=3

# Apply battery optimization level
case $BATTERY_OPTIMIZATION_LEVEL in
    1)
        echo "Applying default battery optimization"
        # Add default battery optimization commands here
        ;;
    2)
        echo "Applying medium battery optimization"
        # Add medium battery optimization commands here
        ;;
    3)
        echo "Applying maximum battery optimization"
        # Add maximum battery optimization commands here
        ;;
    *)
        echo "Invalid battery optimization level. Using default optimization"
        # Add default battery optimization commands here
        ;;
esac

# Increase GPU buffer size for smoother visualization
echo "10 10 20" > /sys/class/drm/card0/device/gpu_boost

# Set the proper permissions for the module
# chmod 755 ${MODDIR}
# chmod 755 ${MODDIR}/service.sh

# Set up render speed parameter
echo "1" > /sys/class/graphics/fb0/draw_bounce_complete

# Set display properties
echo "1" > /sys/class/graphics/fb0/external_mode
# echo "performance" > /sys/class/graphics/fb0/graphics/fb_governor

# Set WiFi Power Saving Mode to off
echo "0" > /sys/module/wake_lock/parameters/active_mode

# Enable TCP Fast Open
echo "3" > /proc/sys/net/ipv4/tcp_fastopen

# Enable WiFi Ad-Hoc Mode
mkdir /data/misc/wifi
echo "1" > /data/misc/wifi/p2p_supplicant_overlay.conf

# Disable WiFi power management
iw wlan0 set power_save off

# Script
nohup sh $MODDIR/script/shellscript > /dev/null &
nohup sh $MODDIR/script/shellscript1 > /dev/null &

# Other commands or settings if required
sync && echo 3 > /proc/sys/vm/drop_caches
echo "Optimizations applied successfully!"

# Disable other unnecessary debugging options as per your needs

exit 0
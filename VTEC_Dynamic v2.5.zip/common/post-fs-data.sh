#!/system/bin/sh
MODDIR=${0%/*}

write /proc/sys/vm/page-cluster 0
write /sys/block/zram0/max_comp_streams 8

{
while true; do
        resetprop  -n persist.sys.thermal.config 10
        resetprop  -n persist.sys.power.default.powermode performance
        sleep 1;
    done
} &

# Toggle 3D and Rendering Optimization
TOGGLE_3D=1
TOGGLE_RENDERING=1

# Set the rendering thread priority to a high value
echo -17 > /proc/$$/taskset/cpuset/camera-daemon/cgroup.sched_boost

# Disable CPU frequency throttling
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/interactive/; do
    echo 0 > "${cpu}enable_freq_resp"
    echo 0 > "${cpu}boost"
done


#!/system/bin/sh
MODDIR=${0%/*}

# Waiting Device Booted
while [[ "$(getprop sys.boot_completed)" -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
   sleep 5
done

sleep 60

perfboost()
{
	for CPU in `ls /sys/devices/system/cpu/cpu*/online`; do
		if [ -f $CPU ]; then
			echo "1" > $CPU
		fi
	done

	for POLICY_PATH in `ls -d /sys/devices/system/cpu/cpufreq/policy*`; do
		if [ -f $POLICY_PATH/cpuinfo_max_freq ] && [ -f $POLICY_PATH/scaling_max_freq ]; then
			echo "$(cat $POLICY_PATH/cpuinfo_max_freq)" > $POLICY_PATH/scaling_max_freq
		fi
		if [ -f $POLICY_PATH/cpuinfo_min_freq ] && [ -f $POLICY_PATH/scaling_min_freq ]; then
			echo "$(cat $POLICY_PATH/cpuinfo_min_freq)" > $POLICY_PATH/scaling_min_freq
		fi
	done
}

# Setting highspeed gov
for gov in /sys/devices/system/cpu/*/cpufreq
do
   echo "99" > $gov/schedutil/hispeed_load
   echo "99" > $gov/walt/hispeed_load
done

# Disable Core_ctl  
for cctl in /sys/devices/system/cpu/*/core_ctl
do
  echo "0" > $cctl/enable
done
  
# Adreno Idler
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active

# Disable LPM Parameters
for parameters in /sys/module/lpm_levels/parameters/*
do
    echo "0" > "$parameters/sleep_disabled"
    echo "0" > "$parameters/lpm_prediction"
    echo "0" > "$parameters/lpm_ipi_prediction"
done

# configure LPM
echo "N" > /sys/module/lpm_levels/system/pwr/cpu0/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/cpu1/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/cpu2/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/cpu3/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu4/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu5/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu6/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/cpu7/ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/pwr-l2-dynret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/perf-l2-dynret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/pwr/pwr-l2-ret/idle_enabled
echo "N" > /sys/module/lpm_levels/system/perf/perf-l2-ret/idle_enabled

#Tweak For Balance Cpu Core
echo "1" > /dev/cpuset/sched_relax_domain_level
echo "1" > /dev/cpuset/system-background/sched_relax_domain_level
echo "1" > /dev/cpuset/background/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-background/sched_relax_domain_level
echo "1" > /dev/cpuset/foreground/sched_relax_domain_level
echo "1" > /dev/cpuset/top-app/sched_relax_domain_level
echo "1" > /dev/cpuset/restricted/sched_relax_domain_level
echo "1" > /dev/cpuset/asopt/sched_relax_domain_level
echo "1" > /dev/cpuset/camera-daemon/sched_relax_domain_level

# Change I/O
echo "deadline" > /sys/block/mtdblock0/queue/scheduler
echo "deadline" > /sys/block/mmcblk0/queue/scheduler
echo "deadline" > /sys/block/mmcblk1/queue/scheduler
echo "deadline" > /sys/block/sda/queue/scheduler
echo "deadline" > /sys/block/sdb/queue/scheduler
echo "deadline" > /sys/block/sdc/queue/scheduler
echo "deadline" > /sys/block/sdd/queue/scheduler
echo "deadline" > /sys/block/sde/queue/scheduler
echo "deadline" > /sys/block/sdf/queue/scheduler

# CPU TEMP 
# echo "0" > /sys/class/thermal/thermal_zone*/mode
echo "0" > /sys/module/overheat_mitigation/parameters/enable
# echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
# echo "0" > /sys/class/kgsl/kgsl-3d0/thermal_pwrlevel
echo "performance" > /sys/class/devfreq/1d84000.ufshc/governor
# echo "10" > /sys/class/thermal/thermal_message/sconfig
# echo "0" > /sys/class/thermal/thermal_message/cpu_limits
# echo "0" > /sys/class/thermal/thermal_message/cpu_nolimit_temp
# echo "1" > /sys/class/thermal/thermal_message/balance_mode
# echo "0" > /sys/class/thermal/thermal_message/temp_state

# Force Thermal Dynamic Evaluation
chmod 0777 /sys/class/thermal/thermal_message/sconfig
echo "10" > /sys/class/thermal/thermal_message/sconfig
chmod 0444 /sys/class/thermal/thermal_message/sconfig

# Hotplug
for hotplug in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl 
do
    write $hotplug/enable "0"
done 

su -c cmd power set-fixed-performance-mode-enabled true
su -c settings put system power_mode high
# su -c settings put system speed_mode 1
su -c settings put secure speed_mode_enable 1
su -c settings put system thermal_limit_refresh_rate 0
su -c settings put global transition_animation_duration_ratio 0.2
su -c settings put global block_untrusted_touches 0
# su -c settings put secure allow_heat_cooldown_always 0

# ข้อความ
su -lp 2000 -c "cmd notification post -S bigtext -t '🔥TWEAK🔥' 'Tag' 'Performance ⚡ปรับแต่ง⚡ CPU GPU UNLOCKLIMIT Successfull FixBy@RealHard️'"

# Bettery Friendly
# echo "N" > /sys/module/workqueue/parameters/power_efficient 
# echo "N" > /sys/module/battery_saver/parameters/enabled
echo "200" > /sys/class/power_supply/bms/temp_cool
echo "460" > /sys/class/power_supply/bms/temp_hot
echo "300" > /sys/class/power_supply/bms/temp_warm

# Enable Fast Charge for slightly faster battery charging when being connected to a USB 3.1 port
echo 1 > /sys/kernel/fast_charge/force_fast_charge

# Disable scheduler statistics to reduce overhead
write /proc/sys/kernel/sched_schedstats "0"

# We are not concerned with prioritizing latency
write /dev/stune/top-app/schedtune.prefer_idle "0"

# Mark top-app as boosted, find high-performing CPUs
write /dev/stune/top-app/schedtune.boost "1"

# Optimize SQLite settings for faster database access
echo "pragma synchronous = off;" > /data/local/tmp/sqlite_optimize.sql
sqlite3 /data/data/com.android.providers.settings/databases/settings.db < /data/local/tmp/sqlite_optimize.sql

# Kernel Debugging & Log (thx to KTSR)
for i in 'debug_mask' 'log_level*' 'debug_level*' '*debug_mode' 'edac_mc_log*' 'enable_event_log' '*log_level*' '*log_ue*' '*log_ce*' 'log_ecn_error' 'snapshot_crashdumper' 'seclog*' 'compat-log' '*log_enabled' 'tracing_on' 'mballoc_debug'; do
    for o in $(find /sys/ -type f -name "$i"); do
        echo "0" > "$o"
done

# Apply changes
echo 0 > /proc/sys/kernel/randomize_va_space
echo 0 > /proc/sys/vm/compact_unevictable_allowed

# Script
nohup sh $MODDIR/script/shellscript > /dev/null &

# Other commands or settings if required
sync && echo 1 > /proc/sys/vm/drop_caches
echo "Optimizations applied successfully!"

# Disable other unnecessary debugging options as per your needs
exit 0